﻿configuration InstallADFS 
{ 
   <# Version = v0.1
   Description: This DSC will add the server to the domain and install ADFS role
   Change Record
   Date          Author               Comments
   01/09/16      Niv                  Created version of this script off previous script
   #>

   param
    (
        [string[]]$NodeName="localhost",

        [Parameter(Mandatory)]
        [string]$MachineName,
      
        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

    #Import the required DSC Resources
    Import-DscResource -Module xComputerManagement, xActiveDirectory, xPendingReboot
    

    Node $NodeName
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        }


        WindowsFeature installADFS  #install ADFS
        {
            Ensure = "Present"
            Name   = "ADFS-Federation"
        }
    }
}